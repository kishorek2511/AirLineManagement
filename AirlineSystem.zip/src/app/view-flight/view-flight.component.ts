import { Component, OnInit } from "@angular/core";
import { DataService } from "../data.service";
import { AirLine } from "../airline-data";
import { Router } from "@angular/router";
import {
  FormGroup,
  FormControl
} from "@angular/forms";

@Component({
  selector: "app-view-flight",
  templateUrl: "./view-flight.component.html"
})
export class ViewFlightComponent implements OnInit {
  searchTerm: string = "";
  displayData: boolean;
  airline: AirLine;
  airLines: AirLine[];
  flightFormGroup: FormGroup;
  constructor(private dataservice: DataService, private router: Router) {}
  getFlights() {
    this.dataservice.getFlights().subscribe(data => {
      this.airLines = data;
    });
  }
  ngOnInit() {
    this.flightFormGroup = new FormGroup({
      providerName: new FormControl(""),
      providerCode: new FormControl(""),
      providerType: new FormControl("")
    });

    this.getFlights();
  }
}
