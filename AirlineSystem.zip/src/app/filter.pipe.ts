import { Pipe, PipeTransform } from '@angular/core';
import { AirLine } from "./airline-data";
@Pipe({
  name: 'flightFilter'
})
export class FlightFilterPipe implements PipeTransform {
  transform(airLines: any, searchTerm: any):any {
    if (searchTerm === "") {
      return airLines;
      console.log("airLines");
    }
    else{
      return airLines.filter(
        function(x){
          return x.providerType.includes(searchTerm);
        }
      )
    }
  }
}
