import {AbstractControl} from '@angular/forms'
import { AirLine } from "./airline-data";

export function providerTypeValidator(control: AbstractControl){

if(control.value == 'International' || control.value == 'Domestic'){
  return null;
}
else{
  return  {'type':true};
}

} 