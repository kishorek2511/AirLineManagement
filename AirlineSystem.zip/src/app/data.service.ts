import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable, throwError } from "rxjs";
import { tap, catchError, map } from "rxjs/operators";
import { AirLine } from "./airline-data";

@Injectable({
  providedIn: "root"
})
export class DataService {
  apiurl = "api/airLines";
  headers = new HttpHeaders()
    .set("Content-Type", "application/json")
    .set("Accept", "application/json");
  httpOptions = {
    headers: this.headers
  };

  constructor(private http: HttpClient) {} //Injecting HTTP service to communicate with the data

  private handleError(error: any) {
    console.error(error); //Created a function to handle and log errors, in case
    return throwError(error);
  }
  getFlights(): Observable<AirLine[]> {
    return this.http.get<AirLine[]>(this.apiurl).pipe(
      tap(data => console.log(data)),
      catchError(this.handleError)
    );
  }
  getFlight(id: number): Observable<AirLine> {
    const url = `${this.apiurl}/${id}`;
    return this.http.get<AirLine>(url).pipe(catchError(this.handleError));
  }

  addFlight(airline: AirLine): Observable<AirLine> {
    airline.id = null;
    return this.http.post<AirLine>(this.apiurl, airline, this.httpOptions).pipe(
      tap(data => console.log(data)),
      catchError(this.handleError)
    );
  }

  deleteFlight(id: number): Observable<AirLine> {
    const url = `${this.apiurl}/${id}`;
    return this.http
      .delete<AirLine>(url, this.httpOptions)
      .pipe(catchError(this.handleError));
  }

  updateFlight(airline: AirLine): Observable<AirLine> {
    const url = `${this.apiurl}/${airline.id}`;
    return this.http.put<AirLine>(url, airline, this.httpOptions).pipe(
      map(() => airline),
      catchError(this.handleError)
    );
  }
}
