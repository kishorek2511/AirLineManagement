import {AbstractControl} from '@angular/forms'
import { AirLine } from "./airline-data";

export function providerCodeValidator(control: AbstractControl){


      if (control.value=='6E-'|| control.value=='9W-'||control.value=='EK-' || control.value=='SG-' ||control.value=='I5-'||control.value=='G8-'||control.value=='AI-') {
return null;
      }
      else{
        return {'code':true};
      }
 
} 