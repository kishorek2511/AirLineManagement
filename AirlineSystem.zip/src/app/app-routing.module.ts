import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { HomeComponent } from "./home/home.component";
import { ViewFlightComponent } from "./view-flight/view-flight.component";
import { CreateflightComponent } from "./create-flight/create-flight.component";
import { DeleteFlightComponent } from "./delete-flight/delete-flight.component";
import { ModifyFlightComponent } from "./modify-flight/modify-flight.component";

const routes: Routes = [
  { path: "home", component: HomeComponent },
  { path: "", redirectTo: "home", pathMatch: "full" },
  { path: "view", component: ViewFlightComponent },
  { path: "create", component: CreateflightComponent },
  { path: "delete", component: DeleteFlightComponent },
  { path: "modify", component: ModifyFlightComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
