export class AirLine {
  constructor(
    public id = 0,
    public providerName = "",
    public providerCode = "",
    public providerType = ""
  ) {}
}
