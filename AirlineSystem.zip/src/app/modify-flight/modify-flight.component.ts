import { Component, OnInit } from "@angular/core";
import {
  FormGroup,
  FormControl,
  FormBuilder,
  Validators
} from "@angular/forms";
import { DataService } from "../data.service";
import { AirLine } from "../airline-data";
import { Router } from "@angular/router";
import {providerTypeValidator} from '../providertype';
import {providerCodeValidator} from '../providercode';


@Component({
  selector: "app-modify-flight",
  templateUrl: "./modify-flight.component.html"
})
export class ModifyFlightComponent implements OnInit {
  displayData: boolean;
  isAirlinePresent = false;
 

  airline: AirLine;
  airlines: AirLine[];
  flightFormGroup: FormGroup;

  constructor(
    private dataservice: DataService,
    private router: Router,
    private formbuilder: FormBuilder
  ) {}
  getFlights() {
    this.dataservice.getFlights().subscribe(data => {
      this.airlines = data;
    });
  }
 

  ngOnInit() {
    this.flightFormGroup = new FormGroup({
      providerName: new FormControl(""),
      providerCode: new FormControl("",[providerCodeValidator]),
      providerType: new FormControl("",[providerTypeValidator])
    });

    this.getFlights();
  }

  checkAirlineExist() {
    this.isAirlinePresent = false;

    this.dataservice.getFlights().subscribe(data => {
      this.airlines = data;
      this.airlines.forEach(element => {
        if (
          element.providerCode == this.codetoUpdate &&
          element.providerType == this.typetoUpdate
        ) {
          this.isAirlinePresent = true;

        } else {
          return null;
        }
      });
    });
  }

  typetoUpdate = "";
  codetoUpdate = "";
  airlineId = 0;
  updateFlight() {
    this.airlines.forEach(element => {
      if (element.providerCode == this.codetoUpdate) {
        this.airlineId = element.id;
        
        console.log(this.airlineId);
        this.dataservice.getFlight(this.airlineId).subscribe(data => {
          this.airline = data;
          
          if (
           element.providerCode == this.codetoUpdate &&
          element.providerType != this.typetoUpdate
          ) {
            this.isAirlinePresent = false;
            this.airline.providerType = this.typetoUpdate;

            this.dataservice.updateFlight(this.airline).subscribe(data1 => {
           
              this.router.navigate(["/home"]);
            });
          }
     else{
       this.isAirlinePresent=true;
     }
        });
      }
          
    });
  }
}
